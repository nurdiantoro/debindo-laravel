<li class="relative  group h-full py-5 navlink text-white">
    <a href="{{ $link }}" target="blank" class=" text-sm font-semibold  px-4 ">
        <i class="{{ $children }}"></i>
    </a>
    <span
        class="bg-blue-800 w-0 h-1 block absolute bottom-0 group-hover:w-full ease-['ease-out'] duration-300 left-1/2 -translate-x-1/2"></span>
</li>
