<li class="nav-item ">
    <a href={{ @(yield 'link') }}>{{ @(yield 'children') }}</a>
</li>
