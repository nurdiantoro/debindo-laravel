
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        </div>

        <!-- Youtube -->
        <div class="my-5">
            <h1 class="h3 mb-0 text-gray-800">Youtube</h1>
            <button class="btn-sm btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#modalTambahYoutube"><i
                    class="fas fa-plus"></i> Tambah Youtube </button>
            <table id="table_youtube" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Thumbnail</th>
                        <th>Title</th>
                        <th>Link</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $youtubes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $youtube): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><img src="<?php echo e(asset('assets/img/youtube/' . $youtube->thumbnail)); ?>" height="100px"></td>
                            <td><?php echo e($youtube->title); ?></td>
                            <td><?php echo e($youtube->link); ?></td>
                            <td class="d-flex flex-nowrap">
                                <button class="btn btn-sm btn-primary mr-2 tombol_edit_youtube" data-bs-toggle="modal"
                                    data-bs-target="#modalEditYoutube" data-id="<?php echo e($youtube->id); ?>"
                                    data-thumbnail="<?php echo e($youtube->thumbnail); ?>" data-title="<?php echo e($youtube->title); ?>"
                                    data-link="<?php echo e($youtube->link); ?>">Edit</button>
                                <a href="<?php echo e(url('dashboard/youtube/delete/' . $youtube->id)); ?>"
                                    class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Event Carousel -->
        <div class="my-5">
            <h1 class="h3 mb-0 text-gray-800">Event Carousel</h1>
            <button class="btn-sm btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#modalTambahEventCarousel"><i
                    class="fas fa-plus"></i> Tambah Event Carousel </button>
            <table id="table_event_carousel" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Urutan</th>
                        <th class="text-left">Image</th>
                        <th>Title</th>
                        <th>Subtitle</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $event_carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event_carousel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($event_carousel->urutan); ?></td>
                            <td class="text-left"><img src="<?php echo e(asset('assets/img/event/' . $event_carousel->foto)); ?>"
                                    height="100px">
                            </td>
                            <td><?php echo e($event_carousel->title); ?></td>
                            <td><?php echo e($event_carousel->subtitle); ?></td>
                            <td class="d-flex flex-nowrap w-full">
                                <a class="btn btn-sm btn-primary mr-2 tombol_edit_event_carousel" data-bs-toggle="modal"
                                    data-bs-target="#modalEditEventCarousel" data-id="<?php echo e($event_carousel->id); ?>"
                                    data-title="<?php echo e($event_carousel->title); ?>"
                                    data-subtitle="<?php echo e($event_carousel->subtitle); ?>"
                                    data-foto="<?php echo e($event_carousel->foto); ?>"
                                    data-urutan="<?php echo e($event_carousel->urutan); ?>">Edit</a>
                                <a href="<?php echo e(url('dashboard/event_carousel/delete/' . $youtube->id)); ?>"
                                    class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="mb-5">
            <h1 class="h3 mb-0 text-gray-800">Testimoni</h1>
            <button class="btn-primary btm-sm mb-2" data-bs-toggle="modal" data-bs-target="#modalTambahTestimoni"><i
                    class="fas fa-plus"></i> Tambah Testimoni</button>
            <table id="example" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Foto</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Testimoni</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimoni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><img src="<?php echo e(asset('assets/img/testimoni/' . $testimoni->foto)); ?>" height="100px"></td>
                            <td><?php echo e($testimoni->nama); ?></td>
                            <td><?php echo e($testimoni->jabatan); ?></td>
                            <td><?php echo e($testimoni->testimoni); ?></td>
                            <td class="d-flex flex-nowrap">
                                <a class="btn btn-sm btn-primary mr-2 tombol_edit_testimoni" data-bs-toggle="modal"
                                    data-bs-target="#modalEditTestimoni" data-id="<?php echo e($testimoni->id); ?>"
                                    data-nama="<?php echo e($testimoni->nama); ?>" data-jabatan="<?php echo e($testimoni->jabatan); ?>"
                                    data-testimoni="<?php echo e($testimoni->testimoni); ?>"
                                    data-foto="<?php echo e($testimoni->foto); ?>">Edit</a>
                                <a href="<?php echo e(url('dashboard/testimoni/delete/' . $testimoni->id)); ?>"
                                    class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Modal Youtube-->
        <?php echo $__env->make('backend.components.modal.tambah_youtube', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('backend.components.modal.edit_youtube', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <!-- Modal Event Carousel-->
        <?php echo $__env->make('backend.components.modal.tambah_event_carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('backend.components.modal.edit_event_carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <!-- Modal Testimoni-->
        <?php echo $__env->make('backend.components.modal.tambah_testimoni', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('backend.components.modal.edit_testimoni', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>