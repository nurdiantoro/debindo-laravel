<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Team</h1>
        </div>

        <div class="mb-5">
            <button class="btn btn-primary btm-sm mb-2" data-bs-toggle="modal" data-bs-target="#modalTambahTeam"><i
                    class="fas fa-plus"></i> Tambah Team</button>
            <table id="table_team" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Urutan</th>
                        <th>Foto</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Tingkat Jabatan</th>
                        <th>Email</th>
                        <th>Linkedin</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($team->urutan); ?></td>
                            <td>
                                <div style="height: 100px; width: 100px">
                                    <img src="<?php echo e(asset('assets/img/team/' . $team->foto)); ?>" class="img-fluid"
                                        style="height: 100px; width:auto;">
                                </div>
                            </td>
                            <td><?php echo e($team->nama); ?></td>
                            <td><?php echo e($team->jabatan); ?></td>
                            <td><?php echo e($team->tingkat_jabatan); ?></td>
                            <td><?php echo e($team->email); ?></td>
                            <td><?php echo e($team->linkedin); ?></td>

                            <td class="d-flex flex-nowrap">
                                <a data-bs-toggle="modal" data-bs-target="#modalEditTeam" data-id="<?php echo e($team->id); ?>"
                                    data-nama="<?php echo e($team->nama); ?>" data-jabatan="<?php echo e($team->jabatan); ?>"
                                    data-tingkat_jabatan="<?php echo e($team->tingkat_jabatan); ?>" data-email="<?php echo e($team->email); ?>"
                                    data-linkedin="<?php echo e($team->linkedin); ?>" data-foto="<?php echo e($team->foto); ?>"
                                    data-urutan="<?php echo e($team->urutan); ?>"
                                    class="btn btn-sm btn-primary mr-2 tombol_edit_team">Edit</a>

                                <a href="<?php echo e(url('dashboard/team/delete/' . $team->id)); ?>"
                                    class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php echo $__env->make('backend.components.modal.tambah_team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('backend.components.modal.edit_team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/backend/team.blade.php ENDPATH**/ ?>