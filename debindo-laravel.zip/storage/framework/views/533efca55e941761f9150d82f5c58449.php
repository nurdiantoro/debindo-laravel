<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Partner</h1>
        </div>

        <div class="mb-5">
            <button class="btn btn-primary btm-sm mb-2" data-bs-toggle="modal" data-bs-target="#modalTambahPartner"><i
                    class="fas fa-plus"></i> Tambah Partner</button>
            <a href="<?php echo e(url('dashboard/partner/urutan')); ?>" class="btn btn-primary btm-sm mb-2"><i class="fas fa-plus"></i>
                Edit Urutan</a>
            <table id="table_partner" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Uturan</th>
                        <th style="width: 50%">Logo</th>
                        <th style="width: 50%">Nama</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($partner->urutan); ?></td>
                            <td>
                                <div style="height: 100px; width: 100px">
                                    <img src="<?php echo e(asset('assets/img/partner/' . $partner->logo)); ?>" class="img-fluid">
                                </div>
                            </td>
                            <td><?php echo e($partner->name); ?></td>
                            <td class="d-flex flex-nowrap">
                                <a href="<?php echo e(url('dashboard/partner/update/' . $partner->id)); ?>"
                                    class="btn btn-sm btn-primary mr-2 tombol_edit_partner">Edit</a>
                                <a href="<?php echo e(url('dashboard/partner/delete/' . $partner->id)); ?>"
                                    class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php echo $__env->make('backend.components.modal.tambah_partner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/backend/partner.blade.php ENDPATH**/ ?>