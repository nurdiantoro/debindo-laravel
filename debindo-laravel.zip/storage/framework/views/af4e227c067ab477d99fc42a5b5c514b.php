<?php $__env->startSection('content'); ?>
    <div id="event">


        <!-- Carousel -->
        <div class="container container-carousel">
            <div class="carousel-event owl-theme owl-carousel">
                <?php $__currentLoopData = $eventCarousel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carousel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="title"><?php echo e($carousel->title); ?>

                            <p><?php echo e($carousel->subtitle); ?></p>
                        </div>
                        <img src="<?php echo e(asset('assets/img/event/' . $carousel->foto)); ?>" alt="" class="img-fluid w-100">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <script>
                $(document).ready(function() {
                    $('.carousel-event').owlCarousel({
                        autoplay: true,
                        autoplayHoverPause: true,
                        autoplayTimeout: 5000,
                        smartSpeed: 1500,
                        items: 1,
                        loop: true,
                        margin: 0,
                        mouseDrag: true,
                        nav: false,
                        touchDrag: true,
                    })
                });
            </script>
        </div>


        <!-- Card -->
        <div class="container">
            <h1>
                <span style="color : var(--warna-01);">This Is </span>Our Journey
            </h1>
            <div class="row text-center">
                <?php $__currentLoopData = $eventDebindo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $debindo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-6 h-100">
                        <a>
                            <div class="card-event">
                                <?php if ($debindo->lokasi == 'Virtual') {?>
                                <object data="<?php echo e(url('assets/img/event/virtual-event.svg')); ?>" class="virtual"></object>
                                <?php }?>

                                <div class="logo-wrapper">
                                    <img src="<?php echo e(url('assets/img/event') . '/' . $debindo->logo); ?>">
                                </div>
                                <span><?php echo e($debindo->judul); ?></span>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>


        <!-- Tabel Event -->
        <div class="container pt-5">
            <table id="table_id" class="display">
                <thead>
                    <tr>
                        <th>Nama Event</th>
                        <th>Tanggal</th>
                        <th>Tahun</th>
                        <th>Lokasi</th>
                        <th>Organized by</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($event->judul); ?></td>
                            <td><?php echo e(date_format(new DateTime($event->tgl_mulai), 'd M')); ?> -
                                <?php echo e(date_format(new DateTime($event->tgl_selesai), 'd M')); ?></td>
                            <td><?php echo e(date_format(new DateTime($event->tgl_selesai), 'Y')); ?></td>
                            <td><?php echo e($event->lokasi); ?></td>
                            <td><?php echo e($event->eo); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <script>
                $(document).ready(function() {
                    $('#table_id').DataTable({
                        "order": [
                            [2, "desc"]
                        ],
                        "columnDefs": [{
                            "targets": 2,
                            "type": "date-eu"
                        }],
                        responsive: true,
                    });
                });
            </script>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/frontend/event.blade.php ENDPATH**/ ?>