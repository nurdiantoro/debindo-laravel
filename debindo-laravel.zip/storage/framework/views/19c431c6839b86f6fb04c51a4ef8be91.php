<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Career</h1>
        </div>

        <div class="mb-5">
            <div class="btn btn-primary btm-sm mb-2"><i class="fas fa-plus"></i> Tambah Career</div>
            <table id="example" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Jabatan</th>
                        <th>Deskripsi</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>>
                            </td>
                            <td><?php echo e($career->jabatan); ?></td>
                            <td><?php echo e($career->deskripsi); ?></td>
                            <td class="d-flex flex-nowrap">
                                <a href="<?php echo e(url('dashboard/career/edit/' . $career->id)); ?>"
                                    class="btn btn-sm btn-primary mr-2">Edit</a>
                                <a href="<?php echo e(url('dashboard/career/delete/' . $career->id)); ?>"
                                    class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/backend/career.blade.php ENDPATH**/ ?>