<li class="hover:text-warna02 relative group h-full py-5 text-white navlink" id="navlink">
    <a href="<?php echo e($link); ?>" class=" text-sm px-4"><?php echo e($children); ?></a>
    <span
        class="bg-blue-800 w-0 h-1 block absolute bottom-0 group-hover:w-full ease-['ease-out'] duration-300 left-1/2 -translate-x-1/2"></span>
</li>
<?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/components/navlink.blade.php ENDPATH**/ ?>