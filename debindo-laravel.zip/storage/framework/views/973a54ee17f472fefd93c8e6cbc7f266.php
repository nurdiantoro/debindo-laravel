<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit Urutan</h1>
        </div>

        <div class="mb-5">
            <a class="btn btn-primary btm-sm mb-2" href="<?php echo e(url('dashboard/partner')); ?>"><i class="fas fa-arrow-left"></i>
                Kembali</a>
            <form method="POST" action="<?php echo e(url('dashboard/partner/update_urutan')); ?>"
                style="width: 50%; display: flex; flex-direction: column; gap: 10px;">
                <?php echo csrf_field(); ?>

                <table class="table">
                    <thead>
                        <td>Logo</td>
                        <td>Nama</td>
                        <td>Urutan</td>
                    </thead>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <input type="hidden" value="<?php echo e($partner->id); ?>" name="id[<?php echo e($partner->id); ?>]">
                            <td><img src="<?php echo e(asset('assets/img/partner/' . $partner->logo)); ?>" style="height: 20px"></td>
                            <td><?php echo e($partner->name); ?></td>
                            <td>
                                <input required type="number" value="<?php echo e($partner->urutan); ?>"
                                    name="urutan[<?php echo e($partner->id); ?>]" class="form-control">
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <button class="btn btn-primary" type="submit">Submit</button>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/backend/update_partner_urutan.blade.php ENDPATH**/ ?>