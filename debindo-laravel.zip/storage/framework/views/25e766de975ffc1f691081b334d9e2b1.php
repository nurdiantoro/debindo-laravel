<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Partner</h1>
        </div>

        <div class="mb-5">
            <a class="btn btn-primary btm-sm mb-2" href="<?php echo e(url('dashboard/partner')); ?>"><i class="fas fa-arrow-left"></i>
                Kembali</a>
            <form method="POST" action="<?php echo e(url('dashboard/partner/update')); ?>" enctype="multipart/form-data"
                style="width: 50%; display: flex; flex-direction: column; gap: 10px;">
                <?php echo csrf_field(); ?>
                <div>
                    <input class="form-control" type="hidden" name="id" id="id" value="<?php echo e($data->id); ?>">
                    <input class="form-control" type="hidden" name="logo_lama" id="logo_lama" value="<?php echo e($data->logo); ?>">
                </div>

                <div>
                    <label for="name">Judul</label>
                    <input class="form-control" type="text" name="name" id="name" value="<?php echo e($data->name); ?>">
                </div>
                <div>
                    <label for="logo">Logo</label>
                    <input class="form-control" type="file" name="logo" id="logo">
                </div>
                <div>
                    <label for="urutan">Urutan</label>
                    <input class="form-control" type="number" name="urutan" id="urutan" value="<?php echo e($data->urutan); ?>">
                </div>
                <button class="btn btn-primary" type="submit">Submit</button>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/backend/update_partner.blade.php ENDPATH**/ ?>