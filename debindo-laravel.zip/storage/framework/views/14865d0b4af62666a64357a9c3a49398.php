<?php $__env->startSection('content'); ?>
    <div id="team">
        <div class="container">
            <h1 class="pb-3">
                <span style="color : var(--warna-01);">WE'RE GLAD YOU KNOW</span> OUR TEAM
            </h1>

            <!-- Direksi -->
            <div class="board-of-director">
                <div class="row justify-content-center">
                    <?php $__currentLoopData = $ourDireksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-12">
                            <div class="card-team direksi">
                                <div class="foto-wrapper">
                                    <img src="<?php echo e(url('assets/img/team') . '/' . $direksi->foto); ?>"alt="">
                                </div>
                                <div class="detail">
                                    <div class="nama">
                                        <?php echo e($direksi['nama']); ?>

                                    </div>
                                    <div class="jabatan">
                                        <?php echo e($direksi['jabatan']); ?>

                                    </div>
                                    <div>
                                        <a href="mailto:<?php echo e($direksi['email']); ?>">
                                            <i class="icon fas fa-envelope"></i>
                                        </a>
                                        <a href="<?php echo e($direksi['linkedin']); ?>">
                                            <i class="icon fab fa-linkedin"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Manajer & Staff -->
            <div class="row justify-content-center">
                <?php $__currentLoopData = $ourManager; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-12">
                        <div class="card-team manager">
                            <div class="foto-wrapper">
                                <img src="<?php echo e(url('assets/img/team') . '/' . $manager->foto); ?>" alt="">
                            </div>
                            <div class="detail">
                                <div class="nama">
                                    <?php echo e($manager['nama']); ?>

                                </div>
                                <div class="jabatan">
                                    <?php echo e($manager['jabatan']); ?>

                                </div>
                                <div>
                                    <a href="mailto:<?php echo e($manager['email']); ?>">
                                        <i class="icon fas fa-envelope"></i>
                                    </a>
                                    <a href="<?php echo e($manager['linkedin']); ?>">
                                        <i class="icon fab fa-linkedin"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $ourStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-12">
                        <div class="card-team staff">
                            <div class="foto-wrapper">
                                <img src="<?php echo e(url('assets/img/team') . '/' . $staff->foto); ?>" alt="">
                            </div>
                            <div class="detail">
                                <div class="nama">
                                    <?php echo e($staff['nama']); ?>

                                </div>
                                <div class="jabatan">
                                    <?php echo e($staff['jabatan']); ?>

                                </div>
                                <div>
                                    <a href="mailto:<?php echo e($staff['email']); ?>">
                                        <i class="icon fas fa-envelope"></i>
                                    </a>
                                    <a href="<?php echo e($staff['linkedin']); ?>">
                                        <i class="icon fab fa-linkedin"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/frontend/team.blade.php ENDPATH**/ ?>