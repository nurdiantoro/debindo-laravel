<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('')); ?>">
            <img src="<?php echo e(url('assets/img/debindo-logo-negative.svg')); ?>" style="height: 54px; width: auto"
                alt="debindo-logo">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02"
            aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav navbar-page">
                <li class="nav-item <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('')); ?>">HOME</a>
                </li>
                <li class="nav-item <?php echo e(request()->is('about') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('about')); ?>">ABOUT</a>
                </li>
                <li class="nav-item <?php echo e(request()->is('team') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('team')); ?>">OUR TEAM</a>
                </li>
                <li class="nav-item <?php echo e(request()->is('event') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('event')); ?>">EVENTS</a>
                </li>
                <li class="nav-item <?php echo e(request()->is('career') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('career')); ?>">CAREER</a>
                </li>
                <li class="nav-item <?php echo e(request()->is('news') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('news')); ?>">NEWS</a>
                </li>
                <li class="nav-item <?php echo e(request()->is('contact') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('contact')); ?>">CONTACT US</a>
                </li>
            </ul>
        </div>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav social-media">
                <li class="nav-item">
                    <a class=" " href="https://www.instagram.com/debindonetwork/" target="blank">
                        <i class="fab fa-instagram"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class=" " href="https://www.facebook.com/DebindoNetwork/" target="blank">
                        <i class="fab fa-facebook"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class=" " href="https://www.youtube.com/channel/UCIPrt0NBCwyNhaKWeSd4iLw?view_as=subscriber"
                        target="blank">
                        <i class="fab fa-youtube"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class=" " href="https://www.linkedin.com/company/debindo/" target="blank">
                        <i class="fab fa-linkedin"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/frontend/components/navbar.blade.php ENDPATH**/ ?>