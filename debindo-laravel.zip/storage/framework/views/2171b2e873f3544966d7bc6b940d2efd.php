
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Events</h1>
        </div>

        <div class="mb-5">
            <button class="btn btn-primary btm-sm mb-2" data-bs-toggle="modal" data-bs-target="#modalTambah"><i
                    class="fas fa-plus"></i> Tambah Event</button>

            <table id="table_event" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Foto</th>
                        <th>Judul</th>
                        <th>Tanggal Mulai</th>
                        <th>Tanggal Selesai</th>
                        <th>Lokasi</th>
                        <th>EO</th>
                        <th>Additional</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div style="height: 50px; width: 100px">
                                    <?php if($event->logo == ''): ?>
                                        <span>tidak ada logo</span>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/img/event/' . $event->logo)); ?>" class="img-fluid"
                                            style="height: 50px">
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td><?php echo e($event->judul); ?></td>
                            <td><?php echo e($event->tgl_mulai); ?></td>
                            <td><?php echo e($event->tgl_selesai); ?></td>
                            <td><?php echo e($event->lokasi); ?></td>
                            <td><?php echo e($event->eo); ?></td>
                            <td><?php echo e($event->addition); ?></td>
                            <td class="d-flex flex-nowrap">
                                <a type="button" class="btn btn-sm btn-primary mr-2 tombol_edit_event" data-toggle="modal"
                                    data-target="#modalEdit" data-id="<?php echo e($event->id); ?>" data-judul="<?php echo e($event->judul); ?> "
                                    data-logo="<?php echo e($event->logo); ?>" data-tgl_mulai="<?php echo e($event->tgl_mulai); ?>"
                                    data-tgl_selesai="<?php echo e($event->tgl_selesai); ?>" data-lokasi="<?php echo e($event->lokasi); ?>"
                                    data-addition="<?php echo e($event->addition); ?>" data-eo="<?php echo e($event->eo); ?>">Edit</a>
                                <a href="<?php echo e(url('dashboard/event/delete/' . $event->id)); ?>"
                                    class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php echo $__env->make('backend.components.modal.tambah_event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('backend.components.modal.edit_event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/backend/event.blade.php ENDPATH**/ ?>