<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Inbox</h1>
        </div>

        <div class="mb-5">
            <table id="table_inbox" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th width='100%'>Pesan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $inboxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($inbox->name); ?></td>
                            <td><?php echo e($inbox->email); ?></td>
                            <td><?php echo e($inbox->subject); ?></td>
                            <td><?php echo e($inbox->message); ?></td>
                            <td class="d-flex flex-nowrap">
                                <a href="<?php echo e(url('dashboard/inbox/edit/' . $inbox->id)); ?>"
                                    class="btn btn-sm btn-primary mr-2">Edit</a>
                                <a href="<?php echo e(url('dashboard/inbox/delete/' . $inbox->id)); ?>"
                                    class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.components.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\debindo-laravel\resources\views/backend/inbox.blade.php ENDPATH**/ ?>